$(function(){
	var width = $(".Video.is-loaded").width();
	var height = $(".Video.is-loaded").height() - 50;
	$(".Video.is-loaded").append('<div class="commentDiv" id="commentDiv" style="position: absolute; top:0; z-index: 999; height:' + height + 'px; width:' + width + 'px;" ></div>');

	var maxLine = 7;
	var lastComId = "";
	var atRatio = 250;
	var lineHeight = 35;
	var rushCriteria = 20;
	var pathname = location.pathname;
	var programid = pathname.split("/")[2];
	var sincemillisecond = 0;
	var nowmillisecond = 0;
	var currentComId = "";
	var currentcomment = "";

	var moveCommentId = setInterval(function(){
    	var commentDiv = document.getElementById('commentDiv');
    	if(commentDiv == null) return;
    	if(commentDiv.style.display == 'none') return;
    	
		var commentList;
		var xhr = new XMLHttpRequest();
		xhr.open("GET", "https://openapi.freshlive.tv/v1/comments?programId="+programid+"&sinceMillisecond="+sincemillisecond+"&order=desc", true);
		xhr.onreadystatechange = function() {
			if (xhr.readyState == 4) {
				var data = JSON.parse(xhr.responseText);
				sincemillisecond = data.meta.latestMillisecond;
				commentList = data.data;

				renderComments(commentList);
		
				// 表示済みコメントの削除
				removeComments(false);

				// フォントの変更適用
				try{
				    var commentDiv = document.getElementById('commentDiv');
					var fontSize = 32;
					var fontColor = "white";
					commentDiv.style.fontSize = fontSize + "px";
					commentDiv.style.color = fontColor;
					
					lineHeight = fontSize + 10;
			    	var comDivHeight = commentDiv.offsetHeight;
					maxLine = Math.floor(comDivHeight / lineHeight);
				}catch(e){}

			};
		}
		xhr.send();
	}, 1100);

	$(window).resize(function(){
		resize();
	});
	/*$(".ControlBar__settingMenuItem").on('click', function(){
		resize();
	});*/

	function resize() {
		var width = $(".Video.is-loaded").width();
		var height = $(".Video.is-loaded").height() - 50;
		$('#commentDiv').height(height);
	    $('#commentDiv').width(width);
	}

	function renderComments(commentList) {
		if(commentList && currentcomment != ""){
			$.each(commentList, function(key, val){
				try{
					var comments = document.getElementsByName('comment');
					currentComId = val['id'];
					currentcomment = val['raw'];
					var dat = new Date();
					var timestamp = dat.getTime();
					if(lastComId == currentComId) return true;
				
					var line = 0;
					var prevline = "";
					var minSpaceLine = 0;

					var i=0;
					while(true){
						if(!(i<maxLine)) break;
						var hit = false;					
						comments = document.getElementsByName('comment');
						
						for(var j=0;j<comments.length;j++){
							var p = comments[j];
							var pUseLine = p.getAttribute('useLine');
							var pline = p.getAttribute('line');
							
							if(i != Number(pUseLine)) continue;
							
							hit = true;
							line = pline;
						}
						
						if(!hit){
							line = i;
							break;
						}

						if(i+1 == maxLine){
							for(var j=0;j<comments.length;j++){
								var p = comments[j];
								var pline = Number(p.getAttribute('line'));
								if(line < pline) line = pline;
							}
							line++;
						}
						i++;
					}
					var useLine = line % maxLine;
					var top = useLine * lineHeight + 5;
					var lcActiveTime = currentcomment.length * atRatio;
					if(lcActiveTime > 5000) lcActiveTime = 5000;
					var activeTime = timestamp + lcActiveTime;
					
					$('#commentDiv').append('<p name="comment" id="' + timestamp + '" line="' + line + '" useLine="' + useLine + '" activeTime="' + activeTime + '" style="top:' + top + 'px; position:absolute; z-index: 9999;"></p>');
					$('#'+timestamp).text(currentcomment);
				}catch(e){}
			});
		}else{
			currentcomment = "default";
		}
		lastComId = currentComId;
	}
	

	function removeComments(allDelete){
		if(allDelete){
			var commentDiv = document.getElementById('commentDiv');
			commentDiv.innerHTML = "";
		}else{
			var comments = document.getElementsByName('comment');
			for(var i=0;i<comments.length;i++){
				var viewTime = Number(comments[i].id);
				var dat = new Date();
				var now = dat.getTime();
				if((now - viewTime) > 5000){
					var el = document.getElementById(eval(viewTime));
					if(null != el)
						el.parentNode.removeChild(el);
				}
			}
		}	
	}

});